# Talkative — Skype-like demo (camera optional, name-based calling)

    Futtatás:
    1. `npm install`
    2. `npm start`
    3. Nyisd meg: http://localhost:3000

    Változtatások, amiket hozzáadtam:
    - Regisztrációkor megadhatsz megjelenítendő nevet (display name). A név alapján is lehet hívni (Call by name).
    - A videó nem kötelező: ha a böngésző vagy a felhasználó megtagadja a kamerát, a rendszer automatikusan visszaesik audio-only módra.
    - Fejlettebb jelenlét (presence) — a szerver broadcastolja az online felhasználók listáját nevekkel.

    Használat:
    - Első megnyitáskor meg kell adnod a megjelenítendő nevet.
    - A kontaktokra kattintva hívhatsz (Call / Video). A Video gomb megkísérli bekapcsolni a kamerát, de ha az nem érhető el, az audio működni fog.
    - A felső "Hívj név szerint" mezőbe beírhatsz egy megjelenítendő nevet (például 'Alice') — a szerver megpróbálja feloldani a nevet az aktív felhasználók között.
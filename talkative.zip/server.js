const express = require('express');
    const http = require('http');
    const WebSocket = require('ws');
    const path = require('path');

    const app = express();
    app.use(express.static(path.join(__dirname, 'public')));

    const server = http.createServer(app);
    const wss = new WebSocket.Server({ server });

    // clients: id -> ws
    const clients = new Map();
    // names: displayName -> id
    const names = new Map();
    // metadata: id -> {name}
    const meta = new Map();

    wss.on('connection', (ws) => {
      let registeredId = null;

      ws.on('message', (msg) => {
        let data;
        try { data = JSON.parse(msg); } catch (e) { return; }
        const { type } = data;

        if (type === 'register' && data.id) {
          registeredId = data.id;
          clients.set(data.id, ws);
          meta.set(data.id, { name: data.name || data.id });
          if (data.name) names.set(data.name, data.id);
          broadcastPresence();
          return;
        }

        // Support calling by name: resolve if 'toName' is present
        if (data.toName) {
          const resolved = names.get(data.toName);
          if (resolved) data.to = resolved;
        }

        if (data.to && clients.has(data.to)) {
          try {
            clients.get(data.to).send(JSON.stringify(data));
          } catch (e) {
            console.error('Forward error', e);
          }
        } else {
          // Broadcast fallback
          wss.clients.forEach((c) => {
            if (c !== ws && c.readyState === WebSocket.OPEN) c.send(msg);
          });
        }
      });

      ws.on('close', () => {
        if (registeredId) {
          const m = meta.get(registeredId);
          if (m && m.name) names.delete(m.name);
          clients.delete(registeredId);
          meta.delete(registeredId);
          broadcastPresence();
        }
      });
    });

    function broadcastPresence() {
      const online = Array.from(meta.entries()).map(([id, m])=>({ id, name: m.name }));
      const msg = JSON.stringify({ type: 'presence', online });
      wss.clients.forEach((c) => {
        if (c.readyState === WebSocket.OPEN) c.send(msg);
      });
    }

    const PORT = process.env.PORT || 3000;
    server.listen(PORT, () => {
      console.log(`Server listening on http://localhost:${PORT}`);
    });
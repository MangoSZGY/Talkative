// client.js
    const WS_URL = (location.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + location.host;
    const ws = new WebSocket(WS_URL);

    const myId = 'user-' + Math.random().toString(36).slice(2,9);
    let myName = localStorage.getItem('talkative_displayName') || null;
    let pc = null;
    let localStream = null;
    let currentTarget = null;
    let isVideo = false;

    const contacts = [
      { id: 'alice', name: 'Alice' },
      { id: 'bob', name: 'Bob' },
      { id: 'carol', name: 'Carol' }
    ];

    function $(id){ return document.getElementById(id); }

    function askDisplayName() {
      if (!myName) {
        myName = prompt('Add meg a megjelenítendő neved (pl. \"Dani#1234\") — ez alapján fognak tudni hívni.') || ('user-' + myId.slice(-4));
        localStorage.setItem('talkative_displayName', myName);
      }
      $('myName').textContent = myName;
      $('myAvatar').textContent = myName[0] || '?';
    }

    function renderContacts(filter='') {
      const el = $('contactsList');
      el.innerHTML = '';
      // Show static contacts + online list will update statuses on presence
      contacts.forEach(c => {
        if (filter && !c.name.toLowerCase().includes(filter.toLowerCase())) return;
        const div = document.createElement('div');
        div.className = 'contact';
        div.dataset.id = c.id;
        div.dataset.name = c.name;
        div.innerHTML = `<div class="c-avatar">${c.name[0]}</div>
                         <div class="c-meta"><div class="c-name">${c.name}</div><div class="c-status" id="status-${c.id}">offline</div></div>`;
        div.onclick = () => selectContact(c.id, c.name);
        el.appendChild(div);
      });
    }

    function selectContact(id, name) {
      currentTarget = id;
      $('targetName').textContent = name;
      $('targetStatus').textContent = '';
      $('callBtn').disabled = false;
      $('videoCallBtn').disabled = false;
      $('messages').innerHTML = '';
    }

    ws.addEventListener('open', () => {
      askDisplayName();
      ws.send(JSON.stringify({ type: 'register', id: myId, name: myName }));
      renderContacts();
    });

    ws.addEventListener('message', async (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.type === 'presence') {
        // msg.online is array of {id,name}
        // update the contact list: show any online users as extra entries
        const el = $('contactsList');
        // Update statuses for known contacts
        document.querySelectorAll('.contact').forEach(elm => {
          const id = elm.dataset.id;
          const statusEl = elm.querySelector('.c-status');
          const found = msg.online.find(x=>x.id===id);
          statusEl.textContent = found ? ('online — ' + found.name) : 'offline';
        });

        // Also add online people who are not in static contacts
        msg.online.forEach(u=>{
          if (u.id === myId) return;
          if (!document.querySelector('.contact[data-id="'+u.id+'"]')) {
            const div = document.createElement('div');
            div.className = 'contact';
            div.dataset.id = u.id;
            div.dataset.name = u.name || u.id;
            div.innerHTML = `<div class="c-avatar">${(u.name||'?')[0]}</div>
                             <div class="c-meta"><div class="c-name">${u.name||u.id}</div><div class="c-status">online</div></div>`;
            div.onclick = () => selectContact(u.id, u.name||u.id);
            el.appendChild(div);
          }
        });

      } else if (msg.type === 'call' && msg.to === myId) {
        await ensureLocalStream(false);
        await createPeer(false, msg.from);
      } else if (msg.type === 'offer' && msg.to === myId) {
        await ensureLocalStream(false);
        await createPeer(false, msg.from);
        await pc.setRemoteDescription(msg.data);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        ws.send(JSON.stringify({ type:'answer', to: msg.from, from: myId, data: pc.localDescription }));
      } else if (msg.type === 'answer' && msg.to === myId) {
        await pc.setRemoteDescription(msg.data);
      } else if (msg.type === 'ice' && msg.to === myId) {
        try {
          await pc.addIceCandidate(msg.data);
        } catch (e) { console.warn('ICE add fail', e); }
      } else if (msg.type === 'chat' && msg.to === myId) {
        appendMessage(msg.text, 'them');
      }
    });

    async function ensureLocalStream(requestVideo=false) {
      if (localStream) return localStream;
      try {
        const constraints = { audio: true, video: requestVideo };
        const s = await navigator.mediaDevices.getUserMedia(constraints);
        localStream = s;
        return s;
      } catch (e) {
        console.warn('No media available or denied', e);
        // if video was requested but failed, try audio-only fallback
        if (requestVideo) {
          try {
            const s = await navigator.mediaDevices.getUserMedia({ audio:true, video:false });
            localStream = s;
            return s;
          } catch (e2) {
            console.warn('Audio also denied or unavailable', e2);
            return null;
          }
        }
        return null;
      }
    }

    async function createPeer(requestVideo, remoteId) {
      pc = new RTCPeerConnection();

      if (localStream) {
        for (const t of localStream.getTracks()) pc.addTrack(t, localStream);
      }

      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          ws.send(JSON.stringify({ type:'ice', to: remoteId, from: myId, data: ev.candidate }));
        }
      };

      pc.ontrack = (ev) => {
        let audio = document.querySelector('audio#remoteAudio');
        if (!audio) {
          audio = document.createElement('audio');
          audio.id = 'remoteAudio';
          audio.autoplay = true;
          document.body.appendChild(audio);
        }
        audio.srcObject = ev.streams[0];
        showCallOverlay(remoteId);
      };

      if (remoteId) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        ws.send(JSON.stringify({ type:'offer', to: remoteId, from: myId, data: pc.localDescription }));
        showCallOverlay(remoteId);
      }
    }

    function showCallOverlay(remoteId) {
      $('callOverlay').classList.remove('hidden');
      const el = document.querySelector('.contact[data-id="'+remoteId+'"]');
      const name = el ? el.dataset.name : remoteId;
      $('callLargeAvatar').textContent = (name?name[0]:'?');
      $('callState').textContent = 'Connected to ' + name;
      $('hangupBtn').disabled = false;
      $('endCall').disabled = false;
    }

    $('callBtn').addEventListener('click', async () => {
      if (!currentTarget) return alert('Válassz kontaktot!');
      isVideo = false;
      await ensureLocalStream(false);
      await createPeer(false, currentTarget);
    });

    $('videoCallBtn').addEventListener('click', async () => {
      if (!currentTarget) return alert('Válassz kontaktot!');
      isVideo = true;
      // Try to get video; if not available, fallback to audio-only automatically
      await ensureLocalStream(true);
      await createPeer(true, currentTarget);
    });

    // Call by name - will send a message with toName, server resolves to id if online
    $('callByNameBtn').addEventListener('click', async () => {
      const name = $('callByNameInput').value.trim();
      if (!name) return alert('Adj meg egy nevet!');
      // try to open mic even if camera not available
      await ensureLocalStream(false);
      // create a temporary peer and send offer to name via server using toName field
      pc = new RTCPeerConnection();
      if (localStream) {
        for (const t of localStream.getTracks()) pc.addTrack(t, localStream);
      }
      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          ws.send(JSON.stringify({ type:'ice', toName: name, from: myId, data: ev.candidate }));
        }
      };
      pc.ontrack = (ev)=>{
        let audio = document.querySelector('audio#remoteAudio');
        if (!audio) {
          audio = document.createElement('audio');
          audio.id = 'remoteAudio';
          audio.autoplay = true;
          document.body.appendChild(audio);
        }
        audio.srcObject = ev.streams[0];
        showCallOverlay(name);
      };
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      ws.send(JSON.stringify({ type:'offer', toName: name, from: myId, data: pc.localDescription }));
      $('callOverlay').classList.remove('hidden');
      $('callLargeAvatar').textContent = name[0]||'?';
      $('callState').textContent = 'Hívás: ' + name;
    });

    $('hangupBtn').addEventListener('click', endCall);
    $('endCall').addEventListener('click', endCall);

    function endCall() {
      if (pc) {
        pc.close();
        pc = null;
      }
      const ra = document.querySelector('audio#remoteAudio');
      if (ra) { ra.srcObject = null; ra.remove(); }
      $('callOverlay').classList.add('hidden');
      $('hangupBtn').disabled = true;
      $('endCall').disabled = true;
      $('callBtn').disabled = false;
      $('videoCallBtn').disabled = false;
    }

    $('sendBtn').addEventListener('click', sendMessage);
    $('messageInput').addEventListener('keydown', (e)=>{ if (e.key==='Enter') sendMessage(); });

    function sendMessage() {
      const txt = $('messageInput').value.trim();
      if (!txt || !currentTarget) return;
      appendMessage(txt, 'me');
      ws.send(JSON.stringify({ type:'chat', to: currentTarget, from: myId, text: txt }));
      $('messageInput').value = '';
    }

    function appendMessage(txt, who) {
      const m = document.createElement('div');
      m.className = 'message ' + (who==='me' ? 'me' : 'them');
      m.textContent = txt;
      $('messages').appendChild(m);
      $('messages').scrollTop = $('messages').scrollHeight;
    }

    $('searchInput').addEventListener('input', (e) => renderContacts(e.target.value));

    renderContacts();